# ObesoCheck — Classificador de Obesidade

Aplicação full stack para predição de nível de obesidade usando machine learning.

```
obesity-app/
├── backend/
│   ├── main.py              ← API FastAPI (servidor)
│   ├── requirements.txt
│   └── model/               ← coloque aqui os arquivos do modelo
│       ├── best_model_*.pkl
│       └── model_metadata.pkl
├── frontend/
│   └── index.html           ← interface do usuário
└── tests/
    └── test_model.py        ← testes automatizados PyTest
```

---

## 1. Pré-requisito: gerar o modelo

Execute o notebook `obesity_classification.ipynb` no Google Colab até o final.
Ao terminar, baixe os arquivos gerados e coloque-os em `backend/model/`:

- `best_model_<nome>.pkl`
- `model_metadata.pkl`

---

## 2. Instalar dependências

```bash
cd backend
pip install -r requirements.txt
```

---

## 3. Iniciar o backend

```bash
cd backend
uvicorn main:app --reload --port 8000
```

Acesse a documentação interativa em: http://localhost:8000/docs

---

## 4. Abrir o frontend

Abra o arquivo `frontend/index.html` diretamente no navegador
(duplo clique ou arraste para o browser).

Ou use um servidor local simples:

```bash
cd frontend
python -m http.server 5500
# acesse http://localhost:5500
```

---

## 5. Executar os testes automatizados

```bash
# da raiz do projeto
pytest tests/test_model.py -v
```

Para ver cobertura:

```bash
pytest tests/test_model.py -v --tb=short
```

Os testes verificam:
- Acurácia global ≥ 85%
- F1-Macro ≥ 83%
- F1-Weighted ≥ 85%
- F1 mínimo por classe ≥ 70%
- Confiança média ≥ 60%
- Modelo não colapsa classes
- Probabilidades somam 1
- Features e classes corretas
- Pipeline íntegro

Se um modelo substituto reprovar em qualquer teste → deploy bloqueado.

---

## Segurança Aplicada

| Prática | Implementação |
|---|---|
| **Input Validation** | Pydantic com whitelist de valores e ranges numéricos |
| **Sem exposição de stack trace** | Handler global retorna mensagem genérica |
| **CORS restrito** | Apenas origens do frontend autorizadas |
| **Logging seguro** | Sem dados pessoais identificáveis nos logs |
| **Fail fast** | Servidor não inicia se modelo ausente/corrompido |
| **Sem armazenamento de dados** | Nenhum dado do usuário é persistido |
| **Validação dupla** | Frontend + backend validam os mesmos campos |
| **Dependências fixadas** | versions pinned em requirements.txt |

"""
Obesity Classification API
Segurança: validação de entrada, CORS restrito, sem exposição de stack trace,
rate limiting conceitual via middleware, logging de predições.
"""

import os
import logging
import re
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, field_validator, model_validator

# ── Logging seguro (sem dados sensíveis em produção) ─────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ── Constantes de validação (Segurança: whitelist de valores permitidos) ──────
VALID_GENDER     = {"Male", "Female"}
VALID_YES_NO     = {"yes", "no"}
VALID_CAEC_CALC  = {"no", "Sometimes", "Frequently", "Always"}
VALID_MTRANS     = {
    "Automobile", "Motorbike", "Bike",
    "Public_Transportation", "Walking"
}

CLASS_LABELS = {
    0: "Insufficient Weight",
    1: "Normal Weight",
    2: "Obesity Type I",
    3: "Obesity Type II",
    4: "Obesity Type III",
    5: "Overweight Level I",
    6: "Overweight Level II",
}

CLASS_COLORS = {
    "Insufficient Weight":  "#3B8BD4",
    "Normal Weight":        "#1D9E75",
    "Overweight Level I":   "#EF9F27",
    "Overweight Level II":  "#D85A30",
    "Obesity Type I":       "#E24B4A",
    "Obesity Type II":      "#C03030",
    "Obesity Type III":     "#8B1010",
}

# ── Carrega modelo embarcado no startup ───────────────────────────────────────
MODEL_DIR = Path(__file__).parent / "model"

def load_artifacts():
    """Carrega pipeline e metadata. Falha rápido se arquivos ausentes."""
    candidates = list(MODEL_DIR.glob("best_model_*.pkl"))
    if not candidates:
        raise FileNotFoundError(
            f"Nenhum arquivo best_model_*.pkl encontrado em {MODEL_DIR}. "
            "Execute o notebook para gerar o modelo antes de iniciar o servidor."
        )
    model_path    = candidates[0]
    metadata_path = MODEL_DIR / "model_metadata.pkl"

    pipeline = joblib.load(model_path)
    metadata = joblib.load(metadata_path)
    logger.info("Modelo carregado: %s", model_path.name)
    logger.info("Acurácia registrada: %.4f", metadata.get("test_accuracy", 0))
    return pipeline, metadata

try:
    pipeline, metadata = load_artifacts()
    MODEL_LOADED = True
except Exception as exc:
    logger.error("Falha ao carregar modelo: %s", exc)
    pipeline, metadata = None, {}
    MODEL_LOADED = False

# ── Aplicação ─────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Obesity Classifier API",
    version="1.0.0",
    docs_url="/docs",        # desabilitar em produção: docs_url=None
    redoc_url=None,
)

# Segurança: CORS restrito à origem do frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5500", "http://127.0.0.1:5500",
                   "http://localhost:3000", "null"],
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

# ── Schema de entrada com validação estrita (Segurança: input validation) ─────
class PredictionInput(BaseModel):
    Gender:                          str
    Age:                             float
    Height:                          float
    Weight:                          float
    family_history_with_overweight:  str
    FAVC:                            str
    FCVC:                            float
    NCP:                             float
    CAEC:                            str
    SMOKE:                           str
    CH2O:                            float
    SCC:                             str
    FAF:                             float
    TUE:                             float
    CALC:                            str
    MTRANS:                          str

    @field_validator("Gender")
    @classmethod
    def validate_gender(cls, v):
        if v not in VALID_GENDER:
            raise ValueError(f"Gender deve ser um de: {VALID_GENDER}")
        return v

    @field_validator("family_history_with_overweight", "FAVC", "SMOKE", "SCC")
    @classmethod
    def validate_yes_no(cls, v):
        if v not in VALID_YES_NO:
            raise ValueError(f"Valor deve ser 'yes' ou 'no'")
        return v

    @field_validator("CAEC", "CALC")
    @classmethod
    def validate_frequency(cls, v):
        if v not in VALID_CAEC_CALC:
            raise ValueError(f"Valor deve ser um de: {VALID_CAEC_CALC}")
        return v

    @field_validator("MTRANS")
    @classmethod
    def validate_mtrans(cls, v):
        if v not in VALID_MTRANS:
            raise ValueError(f"MTRANS deve ser um de: {VALID_MTRANS}")
        return v

    @field_validator("Age")
    @classmethod
    def validate_age(cls, v):
        if not (1 <= v <= 120):
            raise ValueError("Age deve estar entre 1 e 120")
        return v

    @field_validator("Height")
    @classmethod
    def validate_height(cls, v):
        if not (0.5 <= v <= 2.5):
            raise ValueError("Height deve estar entre 0.5 e 2.5 metros")
        return v

    @field_validator("Weight")
    @classmethod
    def validate_weight(cls, v):
        if not (10 <= v <= 300):
            raise ValueError("Weight deve estar entre 10 e 300 kg")
        return v

    @field_validator("FCVC", "NCP", "CH2O", "FAF", "TUE")
    @classmethod
    def validate_scale(cls, v):
        if not (0 <= v <= 10):
            raise ValueError("Valor numérico fora do intervalo esperado (0–10)")
        return v

# ── Endpoints ─────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    """Verificação de saúde — não expõe detalhes internos."""
    return {
        "status": "ok" if MODEL_LOADED else "degraded",
        "model_loaded": MODEL_LOADED,
        "model_name": metadata.get("best_model_name", "unknown"),
    }

@app.get("/model-info")
def model_info():
    """Informações públicas sobre o modelo carregado."""
    if not MODEL_LOADED:
        raise HTTPException(status_code=503, detail="Modelo não disponível.")
    return {
        "model_name":    metadata.get("best_model_name"),
        "test_accuracy": round(metadata.get("test_accuracy", 0), 4),
        "classes":       metadata.get("class_names", []),
        "features":      metadata.get("feature_names", []),
    }

@app.post("/predict")
def predict(data: PredictionInput, request: Request):
    """Realiza predição. Não retorna stack trace em caso de erro."""
    if not MODEL_LOADED:
        raise HTTPException(status_code=503, detail="Modelo não disponível.")

    # Segurança: log sem dados pessoais identificáveis
    logger.info("Predição solicitada de %s", request.client.host if request.client else "unknown")

    try:
        feature_names = metadata["feature_names"]
        le_features   = metadata["le_features"]
        le_target     = metadata["le_target"]

        # Monta dict e codifica categorias com os encoders do treino
        row = data.model_dump()
        for col, le in le_features.items():
            if col in row:
                try:
                    row[col] = int(le.transform([row[col]])[0])
                except ValueError:
                    raise HTTPException(
                        status_code=422,
                        detail=f"Valor inválido para '{col}': '{row[col]}'"
                    )

        X = np.array([[row[f] for f in feature_names]])
        pred_encoded = pipeline.predict(X)[0]
        proba        = pipeline.predict_proba(X)[0]

        pred_label = str(le_target.inverse_transform([pred_encoded])[0])
        confidence = float(np.max(proba))

        # Top-3 classes com probabilidade
        top3_idx = np.argsort(proba)[::-1][:3]
        top3 = [
            {
                "label":       str(le_target.inverse_transform([i])[0]),
                "probability": round(float(proba[i]), 4),
            }
            for i in top3_idx
        ]

        logger.info("Predição: %s (confiança=%.2f)", pred_label, confidence)

        return {
            "prediction":  pred_label,
            "confidence":  round(confidence, 4),
            "color":       CLASS_COLORS.get(pred_label, "#888"),
            "top3":        top3,
        }

    except HTTPException:
        raise
    except Exception:
        # Segurança: nunca expõe traceback ao cliente
        logger.exception("Erro interno na predição")
        raise HTTPException(status_code=500, detail="Erro interno ao processar predição.")

# Segurança: handler global para não vazar detalhes de erros inesperados
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception("Exceção não tratada")
    return JSONResponse(status_code=500, content={"detail": "Erro interno do servidor."})

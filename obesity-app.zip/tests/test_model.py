"""
Testes automatizados do modelo de classificação de obesidade.

Objetivo: garantir que o modelo atenda aos requisitos mínimos de desempenho
antes de ser implantado. Se o modelo for substituído, estes testes barram
a implantação caso o novo modelo fique abaixo dos thresholds.

Execute com:
    pytest tests/test_model.py -v
"""

import sys
from pathlib import Path
import numpy as np
import pytest

# ── Permite importar de backend/ ─────────────────────────────────────────────
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "backend"))

# ── Thresholds de desempenho (requisitos mínimos aceitáveis) ──────────────────
# Estes valores são os "contratos" do modelo.
# Se um modelo substituto não atingir esses números, o deploy é bloqueado.
THRESHOLDS = {
    "accuracy":              0.85,   # Acurácia global mínima
    "f1_macro":              0.83,   # F1 médio sem ponderação (penaliza classes menores)
    "f1_weighted":           0.85,   # F1 ponderado pelo suporte de cada classe
    "per_class_f1_min":      0.70,   # Nenhuma classe pode ter F1 abaixo disso
    "confidence_mean_min":   0.60,   # Confiança média das predições
}

# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def artifacts():
    """Carrega modelo e metadata uma única vez para toda a sessão de testes."""
    import joblib

    model_dir = ROOT / "backend" / "model"
    candidates = list(model_dir.glob("best_model_*.pkl"))

    if not candidates:
        pytest.skip(
            "Arquivo best_model_*.pkl não encontrado. "
            "Execute o notebook para gerar o modelo primeiro."
        )

    pipeline = joblib.load(candidates[0])
    metadata = joblib.load(model_dir / "model_metadata.pkl")
    return pipeline, metadata


@pytest.fixture(scope="session")
def test_data(artifacts):
    """
    Carrega o dataset original e retorna um conjunto de teste reproduzível.
    Usa a mesma semente do treinamento para garantir o mesmo split holdout.
    """
    try:
        from ucimlrepo import fetch_ucirepo
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import LabelEncoder

        dataset = fetch_ucirepo(id=544)
        X_raw = dataset.data.features.copy()
        y_raw = dataset.data.targets.copy()

        pipeline, metadata = artifacts
        le_features = metadata["le_features"]
        le_target   = metadata["le_target"]

        X = X_raw.copy()
        for col, le in le_features.items():
            X[col] = le.transform(X[col])

        y = le_target.transform(y_raw.values.ravel())

        _, X_test, _, y_test = train_test_split(
            X, y, test_size=0.20, stratify=y, random_state=42
        )
        return X_test, y_test

    except Exception as e:
        pytest.skip(f"Não foi possível carregar dados de teste: {e}")


@pytest.fixture(scope="session")
def predictions(artifacts, test_data):
    """Gera predições e probabilidades uma única vez."""
    pipeline, _ = artifacts
    X_test, y_test = test_data
    y_pred  = pipeline.predict(X_test)
    y_proba = pipeline.predict_proba(X_test)
    return y_pred, y_proba, y_test


# ── Testes de desempenho ───────────────────────────────────────────────────────

class TestModelPerformance:

    def test_model_loads_successfully(self, artifacts):
        """O modelo deve carregar sem erros."""
        pipeline, metadata = artifacts
        assert pipeline is not None, "Pipeline não carregado"
        assert metadata is not None, "Metadata não carregada"
        assert "best_model_name" in metadata
        assert "feature_names" in metadata
        assert "class_names" in metadata

    def test_accuracy_above_threshold(self, predictions):
        """Acurácia global deve ser >= THRESHOLDS['accuracy']."""
        from sklearn.metrics import accuracy_score
        y_pred, _, y_test = predictions
        acc = accuracy_score(y_test, y_pred)
        threshold = THRESHOLDS["accuracy"]
        assert acc >= threshold, (
            f"Acurácia {acc:.4f} abaixo do mínimo exigido {threshold:.4f}. "
            "Modelo reprovado — verifique o treinamento antes de implantar."
        )

    def test_f1_macro_above_threshold(self, predictions):
        """F1-Macro deve ser >= THRESHOLDS['f1_macro']."""
        from sklearn.metrics import f1_score
        y_pred, _, y_test = predictions
        f1 = f1_score(y_test, y_pred, average="macro")
        threshold = THRESHOLDS["f1_macro"]
        assert f1 >= threshold, (
            f"F1-Macro {f1:.4f} abaixo do mínimo exigido {threshold:.4f}."
        )

    def test_f1_weighted_above_threshold(self, predictions):
        """F1-Weighted deve ser >= THRESHOLDS['f1_weighted']."""
        from sklearn.metrics import f1_score
        y_pred, _, y_test = predictions
        f1 = f1_score(y_test, y_pred, average="weighted")
        threshold = THRESHOLDS["f1_weighted"]
        assert f1 >= threshold, (
            f"F1-Weighted {f1:.4f} abaixo do mínimo exigido {threshold:.4f}."
        )

    def test_per_class_f1_above_minimum(self, predictions, artifacts):
        """
        Nenhuma classe individual pode ter F1 abaixo de THRESHOLDS['per_class_f1_min'].
        Evita modelos que ignoram classes minoritárias.
        """
        from sklearn.metrics import f1_score
        y_pred, _, y_test = predictions
        _, metadata = artifacts
        class_names = metadata["class_names"]

        f1_per_class = f1_score(y_test, y_pred, average=None)
        threshold = THRESHOLDS["per_class_f1_min"]

        failing_classes = [
            f"{class_names[i]} (F1={f1_per_class[i]:.4f})"
            for i in range(len(f1_per_class))
            if f1_per_class[i] < threshold
        ]
        assert not failing_classes, (
            f"Classes abaixo do F1 mínimo ({threshold}): {failing_classes}"
        )

    def test_mean_confidence_above_threshold(self, predictions):
        """
        Confiança média das predições deve ser >= THRESHOLDS['confidence_mean_min'].
        Modelos muito incertos são problemáticos em produção.
        """
        _, y_proba, _ = predictions
        mean_confidence = float(np.max(y_proba, axis=1).mean())
        threshold = THRESHOLDS["confidence_mean_min"]
        assert mean_confidence >= threshold, (
            f"Confiança média {mean_confidence:.4f} abaixo do mínimo {threshold:.4f}."
        )

    def test_no_class_completely_missed(self, predictions, artifacts):
        """
        O modelo não pode deixar de prever nenhuma classe existente.
        Detecta modelos degenerados que colapsam tudo em uma classe.
        """
        y_pred, _, y_test = predictions
        _, metadata = artifacts
        unique_predicted = set(np.unique(y_pred))
        unique_real      = set(np.unique(y_test))
        missed = unique_real - unique_predicted
        assert not missed, (
            f"Classes presentes no teste mas nunca preditas: {missed}. "
            "Modelo pode estar colapsado."
        )

    def test_prediction_shape_is_correct(self, predictions, test_data):
        """Número de predições deve ser igual ao número de amostras de teste."""
        y_pred, y_proba, _ = predictions
        X_test, _ = test_data
        assert len(y_pred) == len(X_test)
        assert y_proba.shape[0] == len(X_test)

    def test_probabilities_sum_to_one(self, predictions):
        """Probabilidades de cada amostra devem somar 1 (tolerância numérica)."""
        _, y_proba, _ = predictions
        sums = y_proba.sum(axis=1)
        assert np.allclose(sums, 1.0, atol=1e-5), (
            "Probabilidades não somam 1 — pipeline pode estar corrompido."
        )


# ── Testes de contrato da API ──────────────────────────────────────────────────

class TestModelContract:

    def test_feature_names_match_expected(self, artifacts):
        """Features do modelo devem corresponder às esperadas."""
        _, metadata = artifacts
        expected_features = [
            "Gender", "Age", "Height", "Weight",
            "family_history_with_overweight", "FAVC", "FCVC", "NCP",
            "CAEC", "SMOKE", "CH2O", "SCC", "FAF", "TUE", "CALC", "MTRANS"
        ]
        assert metadata["feature_names"] == expected_features, (
            "Nomes das features mudaram — verifique compatibilidade com o frontend."
        )

    def test_number_of_classes(self, artifacts):
        """Modelo deve ter exatamente 7 classes de saída."""
        _, metadata = artifacts
        assert len(metadata["class_names"]) == 7, (
            f"Esperado 7 classes, encontrado {len(metadata['class_names'])}."
        )

    def test_model_accepts_valid_input(self, artifacts):
        """Pipeline deve aceitar e processar uma amostra válida sem erro."""
        import pandas as pd
        pipeline, metadata = artifacts
        le_features = metadata["le_features"]
        feature_names = metadata["feature_names"]

        # Amostra sintética representativa
        sample = {
            "Gender": "Male", "Age": 25.0, "Height": 1.75, "Weight": 70.0,
            "family_history_with_overweight": "yes", "FAVC": "no",
            "FCVC": 2.0, "NCP": 3.0, "CAEC": "Sometimes", "SMOKE": "no",
            "CH2O": 2.0, "SCC": "no", "FAF": 1.0, "TUE": 1.0,
            "CALC": "Sometimes", "MTRANS": "Public_Transportation"
        }

        for col, le in le_features.items():
            if col in sample:
                sample[col] = int(le.transform([sample[col]])[0])

        X = np.array([[sample[f] for f in feature_names]])
        pred = pipeline.predict(X)
        assert pred is not None
        assert len(pred) == 1

    def test_metadata_has_required_keys(self, artifacts):
        """Metadata deve conter todas as chaves necessárias para o servidor."""
        _, metadata = artifacts
        required_keys = [
            "best_model_name", "le_target", "le_features",
            "feature_names", "class_names", "test_accuracy", "best_params"
        ]
        for key in required_keys:
            assert key in metadata, f"Chave '{key}' ausente na metadata."


# ── Testes de segurança básicos ────────────────────────────────────────────────

class TestModelSecurity:

    def test_model_does_not_expose_training_data(self, artifacts):
        """
        Modelo não deve ser um simples lookup de dados de treino.
        Verifica que predições em dados levemente perturbados ainda funcionam.
        """
        import pandas as pd
        pipeline, metadata = artifacts
        le_features   = metadata["le_features"]
        feature_names = metadata["feature_names"]

        sample = {
            "Gender": "Female", "Age": 30.0, "Height": 1.60, "Weight": 90.0,
            "family_history_with_overweight": "yes", "FAVC": "yes",
            "FCVC": 1.0, "NCP": 3.0, "CAEC": "Frequently", "SMOKE": "no",
            "CH2O": 1.0, "SCC": "no", "FAF": 0.0, "TUE": 2.0,
            "CALC": "Sometimes", "MTRANS": "Automobile"
        }
        for col, le in le_features.items():
            if col in sample:
                sample[col] = int(le.transform([sample[col]])[0])

        X1 = np.array([[sample[f] for f in feature_names]])
        sample_copy = sample.copy()
        sample_copy["Age"] = 30.1  # perturbação mínima
        X2 = np.array([[sample_copy[f] for f in feature_names]])

        pred1 = pipeline.predict(X1)[0]
        pred2 = pipeline.predict(X2)[0]
        # Não deve lançar exceção — o modelo deve ser robusto a perturbações
        assert pred1 is not None and pred2 is not None

    def test_pipeline_is_not_empty(self, artifacts):
        """Pipeline deve ter pelo menos 2 etapas (scaler + classificador)."""
        pipeline, _ = artifacts
        assert len(pipeline.steps) >= 2, "Pipeline incompleto."
